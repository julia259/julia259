# Lunar Daybook — a runnable example

This is synthetic demonstration data for booking-desk, curated for the explicitly fictional @julia259 developer persona.

## Try it

Requires Node.js 22+. From the project root run:

```text
node examples/profile-mission/check.mjs
```

Paste bookings.csv into Booking Desk. Two adjacent slots should be accepted. Inspect the generated ICS: local +01:00 times become 08:00 and 08:30 UTC.

Start the full local app using Start.cmd on Windows, or `node server.mjs`; open http://127.0.0.1:8810. The original README contains its complete instructions.

## A useful next change

Add a deliberately overlapping booking and describe the expected rejection.

The example, assertion script and documentation are new local additions. The application, original authors, LICENSE and existing Git history retain their attribution. The source ZIP contains no Git database; publish a separate repository from the original local Git project to retain its history.

# Source snapshot / Lunar Daybook

Project: booking-desk. Curated for @julia259, an explicitly fictional developer persona.

Original source HEAD: `749d557984f6026e62851c7e9c50ddb681d3dd23`. The existing README and LICENSE are preserved. Windows Explorer desktop.ini files are omitted from this distributable. Added synthetic examples are in examples/profile-mission.

Runtime: Node.js 22+. Start: `node server.mjs`. Demo check: `node examples/profile-mission/check.mjs`.

This source download is for trying the application. It excludes .git and commit emails. A separately published repository should use the original project's history.
